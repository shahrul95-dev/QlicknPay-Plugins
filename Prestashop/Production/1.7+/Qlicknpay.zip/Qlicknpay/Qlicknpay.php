<?php
/**
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Qlicknpay extends PaymentModule
{
    protected $_html = '';
    protected $_postErrors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;
    public $api = "undefined";

    public function __construct()
    {
        $this->name = 'Qlicknpay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->author = 'Qlicknpay';
        $this->controllers = array('validation');
        $this->is_eu_compatible = 1;
        $this->module_key = '34d3699a79d524b11ded3082010cf630';

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Qlick N Pay');
        $this->description = $this->l('Payment gateway for transaction');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');


        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module.');
        }
    }

    public function getContent()
    {
      $output = null;

      if (Tools::isSubmit('submit'.$this->name))
      {
          $api = Tools::getValue('API');
          $merchant_id = Tools::getValue('MERCHANT_ID');


          if (!$api  || empty($api) || !Validate::isGenericName($api) ||
          !$merchant_id  || empty($merchant_id) || !Validate::isGenericName($merchant_id))
              $output .= $this->displayError( $this->l('Invalid Configuration value') );
          else
          {

              $this->updateConfigurationPost($api,$merchant_id);
              $output .= $this->displayConfirmation($this->l('Settings updated'));

          }
      }
      return $output.$this->displayForm();
    }

  public function displayForm()
{
    // Get default Language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

    $disp_sql = 'SELECT * FROM '._DB_PREFIX_.'Qlicknpay';
    $disp = Db::getInstance()->getRow($disp_sql);

    // Init Fields form array
    $fields_form = [];

    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Settings'),
        ),
        'input' => array(
            array(
                'type' => 'text',
                'label' => $this->l('API'),
                'placeholder' => $disp['api'],
                'name' => 'API',
                'size' => 20,
                'required' => true
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Merchant ID'),
                'placeholder' => $disp['merchant_id'],
                'name' => 'MERCHANT_ID',
                'size' => 20,
                'required' => true
            )
        ),
        'submit' => array(
            'title' => $this->l('Save'),
            'class' => 'button'
        )
    );

    $helper = new HelperForm();

    // Module, t    oken and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;

    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action = 'submit'.$this->name;
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );

    // Load current value
    $helper->fields_value['API'] = Configuration::get('API');
    $helper->fields_value['MERCHANT_ID'] = Configuration::get('MERCHANT_ID');

    $this->context->controller->addCSS($this->_path . 'views/css/configuration.css');

    $output = $this->display(__FILE__, 'views/templates/admin/configuration.tpl');

    return $output.$helper->generateForm($fields_form);
}

    protected function createTables()
    {
        if (!Db::getInstance()->Execute('
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'Qlicknpay` (
          `api` varchar(255) NOT NULL,
          `merchant_id` varchar(255) NOT NULL,
          PRIMARY KEY (`api`)
        )')
        ) {
            return false;
        }

        return true;
    }

    protected function updateConfigurationPost($api,$merchant_id)
    {
        // Configuration::updateValue('api', $api);
        // Configuration::updateValue('merchant_id',merchant_id);

        $select_all = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'Qlicknpay`');

        $select_all = implode("",$select_all);

        if($select_all == null || empty($select_all))
        {
          $insertData = array(
         'api'  => $api,
         'merchant_id'  => $merchant_id
          );

         Db::getInstance()->insert('Qlicknpay', $insertData);

        }
        else
        {
          $sql = 'UPDATE `' . _DB_PREFIX_ .'Qlicknpay` SET `api`="'.$api.'",`merchant_id`="'.$merchant_id.'"';
          Db::getInstance()->execute($sql);
        }
    }

    public function install()
    {
        if (!parent::install() || !$this->registerHook('paymentOptions') || !$this->registerHook('paymentReturn') || !$this->createTables()) {
            return false;
        }
        return true;
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $payment_options = [
            $this->getExternalPaymentOption($params),
        ];

        return $payment_options;
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }


    public function getExternalPaymentOption($params)
    {
      $sql_api = 'SELECT `api` FROM '._DB_PREFIX_.'Qlicknpay';
      $sql_seller_id = 'SELECT `merchant_id` FROM '._DB_PREFIX_.'Qlicknpay';

      $api = Db::getInstance()->getRow($sql_api);
      $seller_id = Db::getInstance()->getRow($sql_seller_id);

      $api = implode("",$api);
      $seller_id = implode("",$seller_id);

      $amount = number_format($this->context->cart->getOrderTotal(true), 2, '.', '');
      $order_id = ($this->context->cart->id)."PS";
      $name = $this->context->customer->firstname . ' ' . $this->context->customer->lastname;
      $email = $this->context->customer->email;

      $address_class = new Address($this->context->cart->id_address_delivery);

      $address1 = isset($address_class->address1) && !empty($address_class->address1) ? $address_class->address1 : $address_class->address2;
      $address2 = isset($address_class->address2) && !empty($address_class->address2) ? $address_class->address2 : $address_class->postcode;
      $postcode = isset($address_class->postcode) && !empty($address_class->postcode) ? $address_class->postcode : $address_class->city;
      $city= isset($address_class->city) && !empty($address_class->city) ? $address_class->city : $address_class->country;
      $country = isset($address_class->country) && !empty($address_class->country) ? $address_class->country : null;

      $products = $params['cart']->getProducts(true);



      // for(int $i=0; $i < count($products); $i++)
      // {
        $counter = 0;
        $id_image = '';
        $product_name = '';
        $product_price = '';
        $product_quantity = '';

        foreach($products as $key => $value)
        {
            $counter++;
            $id_image_r = Tools::substr($value['id_image'], strpos($value['id_image'], "-") + 1);
            $id_image .=  $id_image_r . "|";
            $product_name .= $value['name'] . "|";
            $product_quantity .= $value['cart_quantity'] . "|";
            $product_price .= number_format((float)$value['price_with_reduction_without_tax'], 2, '.', '') . "|";
        }

        //var_dump($products);
        // echo "<pre>";
        $cart = $this->context->cart;
        $currency = $this->context->currency;

        $cart_id_cust = $cart->id_customer;
        $total_cart = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $cart_id =  $cart->id;

        $data_temp = $cart_id_cust."|".$total_cart."|".$cart_id;
        //var_dump( $customer->secure_key);
        // echo "</pre>";

      // }
      // $products =  implode("",$products);

      // $address = $address1 ." ". $address2 ." ". $postcode ." ". $city;

      // $products = Context::getContext()->cart;
      //
      //
      // $phone = isset($address_class->phone) && !empty($address_class->phone) ? $address_class->phone : $address_class->phone_mobile;

      $hashed_string = md5($api.urldecode($order_id).urldecode($amount).urldecode($email));

        $externalOption = new PaymentOption();
        $externalOption
        // ->setCallToActionText($this->l('Qlicknpay'))
                       ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true))
                       ->setInputs([
                            'amount' => [
                                'name' =>'amount',
                                'type' =>'hidden',
                                'value'=> $amount,
                            ],
                            'order_id' => [
                                'name' =>'order_id',
                                'type' =>'hidden',
                                'value' =>$order_id,
                            ],
                            'name' => [
                                'name' =>'name',
                                'type' =>'hidden',
                                'value' =>$name,
                            ],
                            'email' => [
                                'name' =>'email',
                                'type' =>'hidden',
                                'value' =>$email,
                            ],
                            'address1' => [
                                'name' =>'address1',
                                'type' =>'hidden',
                                'value' =>$address1,
                            ],
                            'address2' => [
                                'name' =>'address2',
                                'type' =>'hidden',
                                'value' =>$address2,
                            ],
                            'poscode' => [
                                'name' =>'poscode',
                                'type' =>'hidden',
                                'value' =>$postcode,
                            ],
                            'city' => [
                                'name' =>'city',
                                'type' =>'hidden',
                                'value' =>$city,
                            ],
                            'country' => [
                                'name' =>'country',
                                'type' =>'hidden',
                                'value' =>$country,
                            ],
                            'hashed_string' => [
                                'name' =>'hashed_string',
                                'type' =>'hidden',
                                'value' =>$hashed_string,
                            ],
                            'seller_id' => [
                                'name' =>'seller_id',
                                'type' =>'hidden',
                                'value' =>$seller_id,
                            ],
                            'id_image' => [
                                'name' =>'id_image',
                                'type' =>'hidden',
                                'value' =>$id_image,
                            ],
                            'product_name' => [
                                'name' =>'product_name',
                                'type' =>'hidden',
                                'value' =>$product_name,
                            ],
                            'product_quantity' => [
                                'name' =>'product_quantity',
                                'type' =>'hidden',
                                'value' =>$product_quantity,
                            ],
                            'product_price' => [
                                'name' =>'product_price',
                                'type' =>'hidden',
                                'value' =>$product_price,
                            ],
                            'counter' => [
                                'name' =>'counter',
                                'type' =>'hidden',
                                'value' =>$counter,
                            ],
                            'comment' => [
                                'name' =>'comment',
                                'type' =>'hidden',
                                'value' =>$data_temp,
                            ],
                        ])
                       ->setAdditionalInformation($this->context->smarty->fetch('module:Qlicknpay/views/templates/front/payment_infos.tpl'))
                        ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/payment.png'));

        return $externalOption;
    }


    protected function generateForm()
    {
        $months = [];
        for ($i = 1; $i <= 12; $i++) {
            $months[] = sprintf("%02d", $i);
        }

        $years = [];
        for ($i = 0; $i <= 10; $i++) {
            $years[] = date('Y', strtotime('+'.$i.' years'));
        }

        $this->context->smarty->assign([
            'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true),
            'months' => $months,
            'years' => $years,
        ]);

        return $this->context->smarty->fetch('module:Qlicknpay/views/templates/front/payment_form.tpl');
    }
}
