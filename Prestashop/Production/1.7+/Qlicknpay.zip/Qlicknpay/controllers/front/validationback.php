<?php
/**
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class QlicknpayValidationBackModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::postProcess()
     */

     public function postProcess()
     {
         $cart = $this->context->cart;
         // $cart = new Cart((int) $_REQUEST['cart_id']);

         $customer = new Customer($cart->id_customer);

         if (!Validate::isLoadedObject($customer))
           Tools::redirect('index.php?controller=order&step=1');


         $currency = $this->context->currency;
         $total = $_REQUEST['total_cart'];

         $merchant_id = $_REQUEST['merchant_id'];
         $invoice = $_REQUEST['invoice'];
         $msg = $_REQUEST['msg'];
         $hash = $_REQUEST['hash'];
         $method = $_REQUEST['pay_method'];

         $sql_api = 'SELECT `api` FROM '._DB_PREFIX_.'Qlicknpay';
         $api = Db::getInstance()->getRow($sql_api);

         $hashed_string = md5($api['api'].$merchant_id.$invoice.$msg);


         $pay_status = 8; // 2 success

         if($msg == 'Transaction Approved' || $msg == 'Success'):
           if($hashed_string == $hash):
             $pay_status = 2;
           else:
             $pay_status = 8;
           endif;
         else:
           $pay_status = 8;
         endif;

         $methodString = "Paying through ".$method;
         $method = " (".$method.")";

         $total = (float)$cart->getOrderTotal(true, Cart::BOTH);


         if($msg == 'Transaction Approved' || $msg == 'Success')
         {
           $this->module->validateOrder((int) $cart->id, $pay_status, $total, $this->module->displayName.$method, $methodString, [], (int)$currency->id, false, $customer->secure_key);

           Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int) $cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
         }
         else
         {
           Tools::redirect('index.php?controller=order&step=1');
         }

      }
}
