<?php

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/Qlicknpay.php');

$Qlicknpay = new Qlicknpay();

$customer = new Customer($_REQUEST['cart_id_cust']);
$cart = new Cart($_REQUEST['cart_id']);

$api = $Qlicknpay->merchant_api;

$total = $_REQUEST['total_cart'];

$merchant_id = $_REQUEST['merchant_id'];
$invoice = $_REQUEST['invoice'];
$msg = $_REQUEST['msg'];
$hash = $_REQUEST['hash'];
$method = $_REQUEST['pay_method'];



$hashed_string = md5($api.$merchant_id.$invoice.$msg.$_REQUEST['cart_id'].$_REQUEST['cart_id_cust']);


$pay_status = 8; // 2 success


if($msg == 'Transaction Approved' || $msg == 'Success'):
  if($hashed_string == $hash):
    $pay_status = 2;
  else:
    $pay_status = 8;
  endif;
else:
  $pay_status = 8;
endif;

$methodString = "Paying through ".$method;
$method = " (".$method.")";
echo "OK";

if($pay_status == 2)
{
  $Qlicknpay->validateOrder($cart->id, _PS_OS_PAYMENT_, $total, $Qlicknpay->displayName, Tools::getValue('ref_Qlicknpay'),'','',false,$customer->secure_key);
}
