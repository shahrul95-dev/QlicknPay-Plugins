<?php
/*
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to https://www.Qlicknpay.com for more information.
*
*  @author Profileo <support@Qlicknpay.com>
*/

if (!defined('_CAN_LOAD_FILES_'))
	exit;

class Qlicknpay extends PaymentModule
{
	private $_html = '';
	private $_postErrors = array();

	public  $merchant_id;
	public  $merchant_api;

	public function __construct()
	{
		$this->name = 'Qlicknpay';
		$this->tab = 'payments_gateways';
		$this->version = '1.0';


		$config = Configuration::getMultiple(array('QLICKNPAY_MERCHANT_ID','QLICKNPAY_MERCHANT_API'));
		if (isset($config['QLICKNPAY_MERCHANT_ID']))
			$this->merchant_id = $config['QLICKNPAY_MERCHANT_ID'];

		if (isset($config['QLICKNPAY_MERCHANT_API']))
			$this->merchant_api = $config['QLICKNPAY_MERCHANT_API'];

		parent::__construct();

		$this->displayName = $this->l('Qlick N Pay');
		$this->description = $this->l('Accept payments by using fpx, credit cards and PayPal');
		$this->confirmUninstall = $this->l('Are you sure you want to delete your details?');
		if (!isset($this->merchant_id))
			$this->warning = $this->l('Account merchant id must be configured in order to use this module correctly');

		if (!isset($this->merchant_api))
			$this->warning = $this->l('Account merchant API must be configured in order to use this module correctly');

		/** Backward compatibility */
		require(_PS_MODULE_DIR_.$this->name.'/backward_compatibility/backward.php');
	}

	public function install()
	{
		return parent::install() && $this->registerHook('payment');
	}

	public function uninstall()
	{
		return Configuration::deleteByName('QLICKNPAY_MERCHANT_ID') && parent::uninstall();
	}

	private function _postValidation()
	{
		if (isset($_POST['submitQlicknpay']) && (empty($_POST['merchant_id']) || empty($_POST['merchant_api'])))
			$this->_postErrors[] = $this->l('account merchant id or merchant api key is required.');

	}

	private function _postProcess()
	{
		if (isset($_POST['submitQlicknpay']))
		{
			if (Tools::getValue('merchant_id'))
				Configuration::updateValue('QLICKNPAY_MERCHANT_ID', Tools::getValue('merchant_id'));

			if (Tools::getValue('merchant_api'))
				Configuration::updateValue('QLICKNPAY_MERCHANT_API', Tools::getValue('merchant_api'));

			$this->_html .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('ok').'" /> '.$this->l('Settings updated').'</div>';
		}
	}

	private function _displayQlicknpay()
	{
		$this->_html .= '
		<img src="../modules/'.$this->name.'/Qlicknpay.png" alt="" />
		<br />
		<fieldset>
			<legend><img src="../modules/'.$this->name.'/logo2.gif" alt="" /> '.$this->l('Qlicknpay').'</legend>
			<div style="float: right; width: 340px; height: 200px; border: dashed 1px #666; padding: 8px; margin-left: 12px; margin-top:-15px;">
				<h2 style="color:#ff9900;">'.$this->l('Our contact email').'</h2>
				<div style="clear: both;"></div>
				<p>'.$this->l('Please contact us if you got any problem').'<br />'.$this->l('Mail : ').'<a href="mailto:support@Qlicknpay.com" style="color:#ff9900;">support@Qlicknpay.com</a></p>
				<p style="padding-top:40px;"><b>'.$this->l('Does not have a Qlicknpay&rsquo;s account yet? Register with us at www.Qlicknpay.com and we will email you a temporary access to a trial sandbox enviroment.').'</b><br /><a href="https://www.Qlicknpay.com" target="_blank" style="color:#ff9900;">https://www.Qlicknpay.my</a></p>
			</div>
			<div style="float:left;text-align:justify;margin-top:3px;width:500px;">
			<b>'.$this->l('Qlick N Pay FPX payment solution for your Online Store.').'</b><br /><br />
			'.$this->l('We believe that collecting payments should be an easy process. Try Qlick N Pay FPX!').'<br /><br />
			'.$this->l('Any E-commerce business should by now have an FPX integration for accepting online payments. Qlick N Pay is the only gateway that enables the merchant to receive INSTANT same day settlement directly into his bank account without having to wait 3-5 days. (*terms and conditions apply).').'<br /><br />
			<u>'.$this->l('Our system also include').'</u><br />
			<b>'.$this->l('E-Invoicing').'</b><br />
			'.$this->l('Let customers pay you instantly with e-invoices. Retails, SME, Wholesaler, Manufacturing.').'<br /><br />
			<b>'.$this->l('QR Billing').'</b><br />
			'.$this->l('Customers pay you by scanning directly on their bill. Telco, utilities, Maintenance, Healthcare.').'<br /><br />
			<b>'.$this->l('Recurring Payments').'</b><br />
			'.$this->l('Direct Debit your customers monthly payment on time. Insurance, Publication, Loans, Software, Education.').'<br /><br />
			<b>'.$this->l('Pay by SMS').'</b><br />
			'.$this->l('Customers can pay you directly from their mobile phone. Retailers, Traders, SME, Logistics.').'<br /><br />
			<b>'.$this->l('Social Shopping Payments').'</b><br />
			'.$this->l('Use Facebook, Instagram, Twitter and others platform to sell and receive payments to your followers. Influence, Online Seller, E-Commerce, Marketplaces.').'<br /><br />
			<b>'.$this->l('Instant Settlements').'</b><br />
			'.$this->l('Express instant settlement into your merchant without having to wait 5 to 7 days to clear.').'<br /><br />
			'.$this->l('You can request your demo account here ').'<a href="https://www.Qlicknpay.com" target="_blank" style="color:#ff9900;">https://www.Qlicknpay.com</a>
			</div><div style="clear:both;">&nbsp;</div>
		</fieldset>';
	}

	private function _displayForm()
	{
		$this->_html .=
		'<form action="'.htmlentities($_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8').'" method="post">
			<fieldset>
				<legend><img src="../modules/'.$this->name.'/logo2.gif" /> '.$this->l('Configuration').'</legend>
				<div style="float:left;"><img src="../modules/'.$this->name.'/img/config_1.png" /></div>
				<div style="float:left; margin-left:10px;"><h2 style="color:#ff9900;">'.$this->l('Request an credentials account (demo/live production)').'</h2>
				'.$this->l('If you need a demo account, redirect to ').'<br /><a href="https://www.Qlicknpay.com" target="_blank" style="color:#ff9900;">https://www.Qlicknpay.com</a> '.$this->l('If you ready to get a live production account, contact us at ').'
				<a href="mailto:support@Qlicknpay.com" style="color:#ff9900;">support@Qlicknpay.com</a></div>
				<div style="clear:both;">&nbsp;</div><br />
				<div style="float:left;"><img src="../modules/'.$this->name.'/img/config_2.png" /></div>
				<div style="float:left; margin-left:10px;width:800px;"><h2 style="color:#ff9900;">'.$this->l('Enter your merchant information').'</h2>'
				.$this->l('To start accepting payments, enter your merchant ID and API secret key. You can retrieve your information from Qlicknpay&lsquo;s dashboard.').'<br/><br/><label style="text-align:left;width:210px;">'.$this->l('Merchant ID').'</label>
				<div><input type="text" size="33" name="merchant_id" value="'.htmlentities(Tools::getValue('merchant_id', $this->merchant_id), ENT_QUOTES, 'UTF-8').'" /></div><br />'.'<br/><br/><label style="text-align:left;width:210px;">'.$this->l('Merchant API').'</label>
				<div><input type="text" size="33" name="merchant_api" value="'.htmlentities(Tools::getValue('merchant_api', $this->merchant_api), ENT_QUOTES, 'UTF-8').'" /> <input type="submit" name="submitQlicknpay" value="'.$this->l('Update settings').'" class="button" /></div><br />
				</div>
				<div style="clear:both;">&nbsp;</div>
			</fieldset>
		</form>';
	}

	public function getContent()
	{

		if (!empty($_POST))
		{
			$this->_postValidation();
			if (!count($this->_postErrors))
				$this->_postProcess();
		}
		else
			$this->_html .= '<br />';

		$this->_displayQlicknpay();
		$this->_html .= '<br />';
		$this->_displayForm();

		return $this->_html;
	}

	public function hookPayment($params)
	{
		$currency = new Currency((int)$params['cart']->id_currency);
		$amount = number_format($params['cart']->getOrderTotal(), 2, '.', '');
		$order_id = $params['cart']->id;

		$customer = new Customer((int)$this->context->cookie->id_customer);

		$address = new Address($this->context->cart->id_address_delivery, intval($this->context->cookie->id_lang));

		$buyer_name = $this->context->cookie->customer_firstname." ".$this->context->cookie->customer_lastname;
		$buyer_email = $this->context->cookie->email;
		$address1 = $address->address1;
		$address2 = $address->address2;
		$phone = $address->phone_mobile;
		$poscode = $address->postcode;
		$city = $address->city;
		$state = $address->country;
		$product = $this->context->cart->getProducts();

		$id_image = "";
		$product_name = "";
		$product_quantity = "";
		$product_price = "";
		$counter = 0;

		foreach($product as $value)
		{
			$counter++;
			$id_image = $id_image.$value['id_image']."|";
			$product_name = $product_name.$value['name']."|";
			$product_quantity = $product_quantity.$value['cart_quantity']."|";
			$product_price = $product_price.$value['price']."|";
		}

		$total_cart = (float)$params['cart']->getOrderTotal(true, Cart::BOTH);
		$cart_id_cust = $params['cart']->id_customer;

		$data_temp = $cart_id_cust."|".$total_cart."|".$order_id;

		$hashed_string = md5(Tools::safeOutput($this->merchant_api).urldecode($order_id).urldecode($amount).urldecode($buyer_email));

		$this->context->smarty->assign(array(
		'seller_id' => Tools::safeOutput($this->merchant_id),
		'order_id' => $order_id,
		'buyer_name' => $buyer_name,
		'amount' => $amount,
		'email' => $buyer_email,
		'address1' => $address1,
		'address2' => $address2,
		'poscode' => $poscode,
		'city' => $city,
		'country' => $state,
		'phone' => $phone,
		'id_image' => $id_image,
		'product_name' => $product_name,
		'product_quantity' => $product_quantity,
		'product_price' => $product_price,
		'counter' => $counter,
		'comment' => $data_temp,
		'hashed_string' => $hashed_string,
		'urlNotification' => 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/Qlicknpay/validation.php',
		'urlError' => 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'index.php?controller=order&step=1',
		'urlReturn' => 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'index.php?controller=history',
		'ref_order' => (int)$this->context->cookie->id_cart));


		return $this->display(__FILE__, 'payment.tpl');
	}
}
