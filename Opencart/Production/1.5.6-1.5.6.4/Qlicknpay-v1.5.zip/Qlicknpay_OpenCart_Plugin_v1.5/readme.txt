Qlick n pay OpenCart plugin for opencart version 1.5

Version 1.0
Author: Shahrul Izwan
Email: shahrul@qlicknpay.com
website: www.qlicknpay.com

license: GNU GPL Version 2

-------------------------
REQUIREMENTS
-------------------------
1. Before using this code, please register with Qlicknpay first. You need to have an account with Qlicknpay before you can use this code

-------------------------
HOW TO USE
-------------------------
1. Download the codes
2. The codes are arrange in the correct folder structure. Simply copy them in the same folder structure
3. To copy, simply drag and drop using FTP application like filezilla.

-------------------------
THE SETUP
-------------------------
1. Login into your Qlicknpay account and get your merchant id and API key
2. Go to extension > payments and find Qlicknpay and click "Install"
3. After that find Qlicknpay again and click "Edit Qlicknpay"
4. Find the fields to enter merchant id and API key and fill in
5. ***"The merchant id and API key is given to you in your Qlicknpay account. You need to log-in and go to Manage API Setting. Scroll down until you see it."***
6. Copy the merchant id and API key and paste them back in the right field.
7. Set Order Status to "Processing" and Order Fail Status to "Failed"
8. Enable it
9. Save.

That is all you need to do. Hopefully you get it.
All the best in your online business.
