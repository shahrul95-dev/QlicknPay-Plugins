<?php
// Text
$_['text_title'] = 'Qlicknpay - Pay with internet banking (FPX) or credit / debit cards';
$_['text_payment_successful'] = 'You payment was successful. Click on the button below to continue. Thank you';
$_['text_payment_failed'] = 'There was a problem with your payment. Click on the button below to continue. Thank you.';
$_['text_payment_title'] = 'Payment status';
