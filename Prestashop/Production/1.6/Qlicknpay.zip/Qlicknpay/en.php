<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{Qlicknpay}prestashop>Qlicknpay_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Are you sure you want to delete your data?';
$_MODULE['<{Qlicknpay}prestashop>Qlicknpay_444bcb3a3fcf8389296c49467f27e1d6'] = 'Ok';
$_MODULE['<{Qlicknpay}prestashop>Qlicknpay_c888438d14855d7d96a2724ee9c306bd'] = 'Updated settings';
$_MODULE['<{Qlicknpay}prestashop>Qlicknpay_740fcd51b628fa236106fb3e86304932'] = 'Mail:';
$_MODULE['<{Qlicknpay}prestashop>Qlicknpay_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{Qlicknpay}prestashop>Qlicknpay_b17f3f4dcf653a5776792498a9b44d6a'] = 'Update the settings';
