<?php
// Text
$_['text_title'] = 'Qlicknpay - Pay with credit / debit cards or internet banking (FPX)';
$_['text_payment_successful'] = 'You payment was successful. Click on the button below to continue. Thank you';
$_['text_payment_failed'] = 'There was a problem with your payment. Click on the button below to continue. Thank you.';
$_['text_payment_title'] = 'Payment status';

//Button
$_['button_success_continue'] = 'Continue';
$_['button_fail_continue'] = 'Try Again';
